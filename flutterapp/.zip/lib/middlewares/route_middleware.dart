import 'package:flutter/cupertino.dart';

abstract class RouteMiddleware {
  Widget next();
}
