class SocialConfig {
  var twitter_consumer_secret = "";
  var twitter_consumer_key = "";

  // var twitter_consumer_secret = "Here your twitter consumer secret key";
  // var twitter_consumer_key = "Here your twitter consumer key";
}
